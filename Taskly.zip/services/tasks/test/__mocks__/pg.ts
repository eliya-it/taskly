export default {
  Pool: class {
    connect = jest.fn();
    query = jest.fn();
    end = jest.fn();
  },
};
