import axios from "axios";

axios.defaults.baseURL = "http://taskly.com/api";

export default axios;
